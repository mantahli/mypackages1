#mypackages1
this library was created as an example of how to publish your own Python packages.

## building this packages locally
 'python setup.py sdist'

## installing this package from github
'pip install git+https://github.com/mantahli/mypackages.git'

## updating this package from github
'pip install --upgrape git+https://github.com/mantahli/mypackages.git'
